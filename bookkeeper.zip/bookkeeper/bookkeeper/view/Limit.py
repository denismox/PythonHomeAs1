from datetime import datetime, timedelta

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QGridLayout, QLabel, QPushButton, QDialog, QLineEdit, QHBoxLayout
)

class ChangeBudgetDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Change Monthly Budget")
        layout = QVBoxLayout(self)

        self.budget_edit = QLineEdit()
        layout.addWidget(QLabel("New Budget:"))
        layout.addWidget(self.budget_edit)

        button_layout = QHBoxLayout()
        save_button = QPushButton("Save")
        cancel_button = QPushButton("Cancel")
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)

        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)

    def get_new_budget(self):
        return self.budget_edit.text()

class BudgetWidget(QWidget):
    def __init__(self, bookkeeper):
        super().__init__()
        self.bookkeeper = bookkeeper
        layout = QVBoxLayout(self)
        self.layout_bud = QGridLayout()

        # Label configuration for budget sections
        labels = {"Remaining": (0, 1), "Budget": (0, 2), "Day": (1, 0), "Week": (2, 0), "Month": (3, 0)}
        for text, pos in labels.items():
            label = QLabel(text)
            label.setAlignment(Qt.AlignCenter)
            self.layout_bud.addWidget(label, *pos)

        # Initialize labels for displaying numbers with styling
        for row in range(1, 4):
            for column in range(1, 3):
                label = QLabel("0")
                label.setStyleSheet("background-color: #f0f0f0; border: 1px solid #d0d0d0; padding: 5px;")
                label.setAlignment(Qt.AlignCenter)
                self.layout_bud.addWidget(label, row, column)

        change_budget_button = QPushButton("Change Monthly Budget")
        change_budget_button.clicked.connect(self.show_change_budget_dialog)
        layout.addLayout(self.layout_bud)
        layout.addWidget(change_budget_button)

        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        self.update_budget()

    def update_budget(self):
        budget = self.bookkeeper.load_budget(1).budget_amount
        expenses = self.bookkeeper.load_expenses()
        today = datetime.today()

        def calc_spent(period):
            return sum(expense.amount for expense in expenses if datetime.strptime(expense.expense_date, "%Y-%m-%d %H:%M:%S.%f") >= today - period)

        # Calculate budget and spent for day, week, month
        budget_day, spent_day = budget / 30, calc_spent(timedelta(days=1))
        budget_week, spent_week = budget / 4, calc_spent(timedelta(weeks=1))
        budget_month, spent_month = budget, calc_spent(timedelta(days=30))

        # Update UI with the calculated values
        self.layout_bud.itemAtPosition(1, 2).widget().setText(f"{budget_day:.2f}")
        self.layout_bud.itemAtPosition(2, 2).widget().setText(f"{budget_week:.2f}")
        self.layout_bud.itemAtPosition(3, 2).widget().setText(f"{budget_month:.2f}")
        self.layout_bud.itemAtPosition(1, 1).widget().setText(f"{budget_day - spent_day:.2f}")
        self.layout_bud.itemAtPosition(2, 1).widget().setText(f"{budget_week - spent_week:.2f}")
        self.layout_bud.itemAtPosition(3, 1).widget().setText(f"{budget_month - spent_month:.2f}")

    def show_change_budget_dialog(self):
        dialog = ChangeBudgetDialog()
        if dialog.exec_() == QDialog.Accepted:
            new_budget = float(dialog.get_new_budget())
            self.bookkeeper.update_budget(1, new_budget)
            self.update_budget()
