from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QComboBox, QHBoxLayout, QDialog,
    QMessageBox, QVBoxLayout, QLabel, QLineEdit, QPushButton, QSplitter
)
from bookkeeper.view.VOperations import VOP


class AddExpense(QWidget):
    def __init__(self, bookkeeper, expenses_widget):
        super().__init__()
        self.bookkeeper = bookkeeper
        self.expenses_widget = expenses_widget
        layout = QVBoxLayout(self)

        self.amount_entry = QLineEdit()
        self.amount_entry.setPlaceholderText("Amount")
        self.category_combobox = QComboBox()
        self.description_entry = QLineEdit()
        self.description_entry.setPlaceholderText("Description")
        self.add_expense_button = QPushButton('Add Transaction')
        self.add_category_button = QPushButton('Add Category')
        self.edit_category_button = QPushButton('Edit Selected Category')
        self.delete_category_button = QPushButton('Delete Selected Category')

        layout.addWidget(QLabel('Amount:'))
        layout.addWidget(self.amount_entry)
        layout.addWidget(QLabel('Comment:'))
        layout.addWidget(self.description_entry)
        layout.addWidget(QLabel('Category:'))

        category_layout = QVBoxLayout()
        category_layout.addWidget(self.category_combobox)
        button_layout = QVBoxLayout()
        button_layout.addWidget(self.add_category_button)
        button_layout.addWidget(self.edit_category_button)
        button_layout.addWidget(self.delete_category_button)

        splitter = QSplitter()
        category_widget = QWidget()
        category_widget.setLayout(category_layout)
        button_widget = QWidget()
        button_widget.setLayout(button_layout)
        splitter.addWidget(category_widget)
        splitter.addWidget(button_widget)
        layout.addWidget(splitter)
        layout.addWidget(self.add_expense_button)

        self.add_expense_button.clicked.connect(self.add_expense)
        self.add_category_button.clicked.connect(self.add_category)
        self.edit_category_button.clicked.connect(self.edit_category)
        self.delete_category_button.clicked.connect(self.delete_category)

        self.update_category_combobox()

    def add_expense(self):
        amount = self.amount_entry.text()
        if not amount:
            QMessageBox.warning(self, "Validation Error", "Amount is required.")
            return
        try:
            amount = float(amount)
        except ValueError:
            QMessageBox.warning(self, "Validation Error", "Amount must be a number.")
            return
        current_index = self.category_combobox.currentIndex()
        category_id = self.category_combobox.itemData(current_index)
        description = self.description_entry.text()
        self.bookkeeper.add_expense(amount, category_id, description)
        self.clear_fields()
        self.expenses_widget.update_expenses()

    def clear_fields(self):
        self.amount_entry.clear()
        self.description_entry.clear()

    def add_category(self):
        self.handle_category_dialog("Add Category", "")

    def edit_category(self):
        current_index = self.category_combobox.currentIndex()
        current_category = self.category_combobox.itemText(current_index)
        self.handle_category_dialog("Edit Category", current_category)

    def handle_category_dialog(self, title, default_text):
        dialog = QDialog()
        dialog.setWindowTitle(title)
        layout = QVBoxLayout(dialog)
        category_name_entry = QLineEdit(default_text)
        layout.addWidget(QLabel("Category Name:"))
        layout.addWidget(category_name_entry)
        save_button = QPushButton("Save" if title == "Add Category" else "Update")
        cancel_button = QPushButton("Cancel")
        button_layout = QHBoxLayout()
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
        save_button.clicked.connect(lambda: self.save_category(category_name_entry.text(), dialog))
        cancel_button.clicked.connect(dialog.reject)
        dialog.exec_()

    def save_category(self, category_name, dialog):
        if not category_name.strip():
            QMessageBox.warning(self, "Validation Error", "Category name cannot be empty.")
            return
        current_index = self.category_combobox.currentIndex()
        category_id = self.category_combobox.itemData(current_index) if current_index >= 0 else None
        if category_id:
            self.bookkeeper.update_category(category_id, category_name)
        else:
            self.bookkeeper.add_category(category_name)
        self.update_category_combobox()
        dialog.accept()

    def delete_category(self):
        current_index = self.category_combobox.currentIndex()
        category_id = self.category_combobox.itemData(current_index)
        if QMessageBox.question(self, "Delete Confirmation", "Are you sure you want to delete the selected category?",
                                QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
            self.bookkeeper.delete_category(category_id)
            self.update_category_combobox()
            self.expenses_widget.update_expenses()

    def update_category_combobox(self):
        self.category_combobox.clear()
        categories = self.bookkeeper.load_categories()
        for category in categories:
            self.category_combobox.addItem(category.name, category.pk)
