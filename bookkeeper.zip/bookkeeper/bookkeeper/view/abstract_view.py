from typing import Generic, TypeVar, Protocol, Any


class AbstractView(Protocol):
    def set_category_list(list[Category]) -> None:
        pass