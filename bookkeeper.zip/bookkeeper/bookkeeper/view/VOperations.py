from datetime import datetime
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QTableWidget, QHeaderView, QAbstractItemView, QTableWidgetItem, QDialog,
    QCalendarWidget, QPushButton, QHBoxLayout, QLineEdit, QComboBox, QLabel, QSpinBox, QMessageBox
)


class EditExpenseDialog(QDialog):
    def __init__(self, expense, bookkeeper):
        super().__init__()
        self.bookkeeper = bookkeeper
        self.expense = bookkeeper.load_expense(expense.pk)
        self.setWindowTitle("Edit Transaction")
        layout = QVBoxLayout(self)

        self.amount_entry = QLineEdit(str(expense.amount))
        self.category_combobox = QComboBox()
        self.description_entry = QLineEdit(expense.comment)
        self.calendar_widget = QCalendarWidget()
        expense_date = datetime.strptime(expense.expense_date, "%Y-%m-%d %H:%M:%S.%f")
        self.calendar_widget.setSelectedDate(expense_date)

        self.hour_spinbox = QSpinBox()
        self.hour_spinbox.setRange(0, 23)
        self.hour_spinbox.setValue(expense_date.hour)
        self.minute_spinbox = QSpinBox()
        self.minute_spinbox.setRange(0, 59)
        self.minute_spinbox.setValue(expense_date.minute)
        self.second_spinbox = QSpinBox()
        self.second_spinbox.setRange(0, 59)
        self.second_spinbox.setValue(expense_date.second)

        layout.addWidget(QLabel('Date:'))
        layout.addWidget(self.calendar_widget)
        layout.addWidget(QLabel('Time:'))

        time_layout = QHBoxLayout()
        time_layout.addWidget(self.hour_spinbox)
        time_layout.addWidget(QLabel(':'))
        time_layout.addWidget(self.minute_spinbox)
        time_layout.addWidget(QLabel(':'))
        time_layout.addWidget(self.second_spinbox)
        layout.addLayout(time_layout)

        layout.addWidget(QLabel('Amount:'))
        layout.addWidget(self.amount_entry)
        layout.addWidget(QLabel('Category:'))
        layout.addWidget(self.category_combobox)
        layout.addWidget(QLabel('Comment:'))
        layout.addWidget(self.description_entry)

        save_button = QPushButton("Save")
        cancel_button = QPushButton("Cancel")
        delete_button = QPushButton("Delete Transaction")
        button_layout = QHBoxLayout()
        button_layout.addWidget(save_button)
        button_layout.addWidget(cancel_button)
        button_layout.addWidget(delete_button)
        layout.addLayout(button_layout)

        save_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        delete_button.clicked.connect(lambda: self.delete_expense(expense.pk))

        self.update_category_combobox()

    def delete_expense(self, pk):
        confirmation = QMessageBox.question(self, "Delete Confirmation",
                                            "Are you sure you want to delete this transaction?",
                                            QMessageBox.Yes | QMessageBox.No)
        if confirmation == QMessageBox.Yes:
            self.bookkeeper.delete_expense(pk)
            self.accept()

    def update_category_combobox(self):
        self.category_combobox.clear()
        for category in self.bookkeeper.load_categories():
            self.category_combobox.addItem(category.name, category.pk)
            if category.pk == self.expense.category:
                self.category_combobox.setCurrentIndex(self.category_combobox.count() - 1)

    def save_changes(self):
        new_date = self.calendar_widget.selectedDate().toString("yyyy-MM-dd")
        new_time = "{:02d}:{:02d}:{:02d}".format(self.hour_spinbox.value(), self.minute_spinbox.value(),
                                                 self.second_spinbox.value())
        new_amount = float(self.amount_entry.text())
        category_id = self.category_combobox.currentData()
        new_description = self.description_entry.text()
        self.bookkeeper.update_expense(self.expense.pk, new_date, new_time, new_amount, category_id, new_description)
        self.accept()


class VOP(QWidget):
    def __init__(self, bookkeeper, budget_widget):
        super().__init__()
        self.bookkeeper = bookkeeper
        self.budget_widget = budget_widget
        layout = QVBoxLayout(self)
        self.init_expense_list()
        layout.addWidget(self.expenses_table)

    def init_expense_list(self):
        self.expenses_table = QTableWidget()
        self.expenses_table.setColumnCount(4)
        self.expenses_table.setHorizontalHeaderLabels(["Date", "Amount", "Category", "Comment"])
        self.expenses_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.expenses_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.expenses_table.verticalHeader().hide()
        self.expenses_table.cellDoubleClicked.connect(self.edit_expense)
        self.update_expenses()

    def edit_expense(self, row, column):
        selected_expense = sorted(self.bookkeeper.load_expenses(), key=lambda x: x.expense_date, reverse=True)[row]
        dialog = EditExpenseDialog(selected_expense, self.bookkeeper)
        if dialog.exec_() == QDialog.Accepted:
            self.update_expenses()

    def update_expenses(self):
        self.expenses_table.clearContents()
        expenses = sorted(self.bookkeeper.load_expenses(), key=lambda x: x.expense_date, reverse=True)
        self.expenses_table.setRowCount(len(expenses))
        for row, expense in enumerate(expenses):
            date_str = datetime.strptime(expense.expense_date, "%Y-%m-%d %H:%M:%S.%f").strftime("%Y-%m-%d %H:%M:%S")
            self.expenses_table.setItem(row, 0, QTableWidgetItem(date_str))
            self.expenses_table.setItem(row, 1, QTableWidgetItem(str(expense.amount)))
            self.expenses_table.setItem(row, 2, QTableWidgetItem(self.bookkeeper.get_category_name(expense.category)))
            self.expenses_table.setItem(row, 3, QTableWidgetItem(expense.comment))
