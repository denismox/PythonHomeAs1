import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QHBoxLayout
from VOperations import VOP
from Limit import BudgetWidget
from Purchases import AddExpense
from bookkeeper.presenter import Bookkeeper

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.bookkeeper = Bookkeeper(self)
        self.setWindowTitle('Budget APP')
        self.budget_widget = BudgetWidget(self.bookkeeper)
        self.expenses_widget = VOP(self.bookkeeper, self.budget_widget)
        self.add_expense_widget = AddExpense(self.bookkeeper, self.expenses_widget)

        layout = QHBoxLayout()
        layout.addWidget(self.expenses_widget)
        add_expense_layout = QVBoxLayout()
        add_expense_layout.addWidget(self.add_expense_widget)
        add_expense_layout.addWidget(self.budget_widget)
        add_expense_layout.addStretch(1)

        add_expense_widget_container = QWidget()
        add_expense_widget_container.setLayout(add_expense_layout)
        layout.addWidget(add_expense_widget_container)
        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
