import sqlite3
from inspect import get_annotations
from typing import List
from .abstract_repository import AbstractRepository, T

class SQLiteRepository(AbstractRepository[T]):
    def __init__(self, db_file: str, cls: type) -> None:
        self.db_file = db_file
        self.table_name = cls.__name__.lower()
        self.fields = get_annotations(cls, eval_str=True)
        self.fields.pop('pk', None)  # Safely attempt to remove 'pk' key
        self.cls = cls

    def add(self, obj: T) -> int:
        fields = ', '.join(self.fields.keys())
        placeholders = ', '.join(['?'] * len(self.fields))
        values = [getattr(obj, field) for field in self.fields]
        with sqlite3.connect(self.db_file) as con:
            con.execute('PRAGMA foreign_keys = ON')
            cur = con.cursor()
            cur.execute(f'INSERT INTO {self.table_name} ({fields}) VALUES ({placeholders})', values)
            obj.pk = cur.lastrowid
        return obj.pk

    def update(self, obj: T) -> None:
        fields = ', '.join(f'{field}=?' for field in self.fields.keys())
        values = [getattr(obj, field) for field in self.fields] + [obj.pk]
        with sqlite3.connect(self.db_file) as con:
            con.execute(f'UPDATE {self.table_name} SET {fields} WHERE pk=?', values)

    def delete(self, pk: int) -> None:
        with sqlite3.connect(self.db_file) as con:
            con.execute(f'DELETE FROM {self.table_name} WHERE pk=?', (pk,))

    def get(self, pk: int) -> T:
        with sqlite3.connect(self.db_file) as con:
            cur = con.cursor()
            cur.execute(f'SELECT * FROM {self.table_name} WHERE pk=?', (pk,))
            row = cur.fetchone()
        return self.cls(*row) if row else None

    def get_all(self) -> List[T]:
        with sqlite3.connect(self.db_file) as con:
            rows = con.execute(f'SELECT * FROM {self.table_name}').fetchall()
        return [self.cls(*row) for row in rows]

    def delete_all_categories(self):
        with sqlite3.connect(self.db_file) as con:
            con.execute(f'DELETE FROM {self.table_name} WHERE table_name="category"')

class SqliteRepositoryHelper:
    def __init__(self, db_name='bookkeeper.db'):
        self.db_name = db_name

    def create_tables(self):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS expense (
                pk INTEGER PRIMARY KEY AUTOINCREMENT,
                amount INTEGER,
                expense_date DATETIME,
                added_date DATETIME,
                category INTEGER,
                comment TEXT,
                FOREIGN KEY (category) REFERENCES category(pk)
            )''')
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS category (
                pk INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                parent INTEGER NULL
            )''')
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS budget (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                budget_amount REAL
            )''')

    def drop_tables(self):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute('DROP TABLE IF EXISTS expense')
            cursor.execute('DROP TABLE IF EXISTS category')
            cursor.execute('DROP TABLE IF EXISTS budget')
