"""
Описан класс, представляющий информацию о бюджете за месяц
"""

from dataclasses import dataclass
@dataclass
class Budget:
    """

    """
    pk: int = 0
    budget_amount: int = 0
