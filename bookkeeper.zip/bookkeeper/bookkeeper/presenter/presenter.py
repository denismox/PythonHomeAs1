from bookkeeper.models import Category, Expense, Budget

from bookkeeper.repository import SQLiteRepository


class Bookkeeper:
    def __init__(self, view):
        self.view = view
        db_file = '/Users/nageeva/Desktop/Denis/bookkeeper/bookkeeper/repository/bookkeeper.db'
        self.category_repository = SQLiteRepository(db_file, Category)
        self.expense_repository = SQLiteRepository(db_file, Expense)
        self.budget_repository = SQLiteRepository(db_file, Budget)

        # Загрузка категорий при инициализации
        # self.load_categories()

        # Загрузка расходов при инициализации
        # self.load_expenses()

        # Загрузка бюджета при инициализации
        # self.load_budget()

    def load_categories(self):
        categories = self.category_repository.get_all()
        return categories

    def add_expense(self, amount, category, comment):
        # Добавить новую операцию в базу данных
        self.expense_repository.add(Expense(amount=amount, category=category, comment=comment))
        # После этого обновить виджет с отображением всех операций
        self.load_expenses()

    def update_expenses(self, expense):
        self.expense_repository.update(expense)

    def add_category(self, name, parent=None):
        self.category_repository.add(Category(name=name, parent=parent))


    def update_category(self, pk, name, parent=None):
        self.category_repository.update(Category(pk=pk, name=name, parent=parent))

    def update_budget(self, pk, budget_amount):
        self.budget_repository.update(Budget(pk=pk, budget_amount=budget_amount))


    def delete_category(self, pk,):
        self.category_repository.delete(pk)

    def delete_expense(self, pk):
        self.expense_repository.delete(pk)

    def get_category_name(self, id):
        if id:
            return self.category_repository.get(id).name
        else:
            return ''

    def load_expenses(self):
        expenses = self.expense_repository.get_all()
        return expenses

    def load_expense(self, pk):
        expense = self.expense_repository.get(pk)
        return expense

    def load_budget(self, pk):
        budget = self.budget_repository.get(pk)
        return budget


